package com.example.a20220801_glennwhite_nycschools.view;

public interface Listener{
 void openDetails(String dbn);
 interface ListClickEvent{
  void clickDetails(String dbn);
 }
}