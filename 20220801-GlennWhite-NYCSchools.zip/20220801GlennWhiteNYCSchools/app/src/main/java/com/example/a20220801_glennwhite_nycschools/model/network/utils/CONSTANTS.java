package com.example.a20220801_glennwhite_nycschools.model.network.utils;

public class CONSTANTS   {
   public static final String BASE_URL = "https://data.cityofnewyork.us/";
   public static final String ENDPOINT_SCHOOL = "resource/s3k6-pzi2.json";
   public static final String ENDPOINT_SAT = "resource/f9bf-2cp4.json";
}
