package com.example.a20220801_glennwhite_nycschools.model.state;
public abstract class UIState {}
